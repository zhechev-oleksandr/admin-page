/**
 * Session object.
 */
export declare class EndUserSession {
    handle: string;
    data: Uint8Array;
}
